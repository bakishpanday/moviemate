using System.Collections.Generic;

namespace MovieMate.Models {
    public class PosterSet {
        public List<Poster> results { get; set; }
        public string page { get; set; }
        public string total_results { get; set; }
        public string total_pages { get; set; }
    }
}