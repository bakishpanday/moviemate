﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MovieMate.MovieAPI;
using MovieMate.Models;

namespace MovieMate.Pages
{
    public class IndexModel : PageModel
    {
        public List<string> posterURLs = new List<string>();
        public List<string> overviews = new List<string>();
        public List<string> movieIDs = new List<string>();

        public void OnGet()
        { }

        public async Task OnPostGetPosters(string search) {
            await Fetch.GrabPosterAsync(search);

            foreach(Poster poster in Program.posterSet.results) {
                posterURLs.Add(poster.poster_path);
                overviews.Add(poster.overview);
                movieIDs.Add(poster.id.ToString());
            }
        } // OnPosterGetPosters()

        public async Task OnPostDetails(string movieID) {
            await Fetch.GetMovieDetails(movieID);

            // ended the day here
            // more more more code to come ;)
        }
    }
}